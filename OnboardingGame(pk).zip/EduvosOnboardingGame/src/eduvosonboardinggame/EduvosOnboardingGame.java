
package eduvosonboardinggame;

import java.util.Scanner;

public class EduvosOnboardingGame {

    
    public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
        String studentName;
        
        System.out.println("==================================================================");
        System.out.println("Get ready to level up!"
                         + "Welcome to the Eduvos- First Week simulation!");
        System.out.println("==================================================================");
        System.out.println("Let's set up your profile!");
        System.out.println();
        
        //Step 1:Player Setup
        System.out.println("Enter your student name: ");
        
        while(true){
            studentName = scanner.nextLine();
            
        //Validating the name
            if (studentName.matches("[a-zA-Z]+")){
                break;
            }else{
                System.out.println("Invalid name! Please use letters only: ");
            }
        }
        
        System.out.println("Welcome, "+ studentName + "! Let's make this an incredible first week!");
        
       //Step 2: Initialise student attributes
        
        Student student = new Student(studentName,70,0);
        
        
        System.out.println("Your starting status: ");
        System.out.println("Student: "+ student.getName());
        System.out.println("Energy: " + student.getEnergy());
        System.out.println("Academic Score: " + student.getAcademicScore());
       
       //Step 3: Scenarios (Day 1-5)
       classScenario[] scenarios = {
           new registration(),
           new LectureScenario(),
           new Assignments(),
           new StudyGroup(),
           new Test()
       };
        
        for (int day = 1; day <= 5; day++){
        
            System.out.println("==================================================================");
        System.out.println("                      DAY" + day);                  
        System.out.println("==================================================================");
        System.out.println("Student: " + student.getName());
        System.out.println("Energy: " + student.getEnergy());
        System.out.println("Academic Score: " + student.getAcademicScore());
        System.out.println("==================================================================");
         
        
        scenarios[day - 1].playclassScenario(student);
        
        if (student.getEnergy() <= 0){
            System.out.println("You have burned out! Energy depleted!");
            System.out.println("GAME OVER.");
            return;
            
        }
    }
        //RESULTS
        System.out.println("==================================================================");
        System.out.println("                    END OF SIMULATION                             ");
        
        System.out.println("==================================================================");
        System.out.println("Final Score: " + student.getAcademicScore());
        
        int score = student.getAcademicScore();
        
        if (score <=40) {
            System.out.println(" POOR PERFORMANCE! Hit the books hard and make it to every class");
        }
        
        else if (score <= 60){
         System.out.println(" AVERAGE PERFORMANCE! Great first attempt, keep going!");
         }
        
        else {
            System.out.println(" EXCELLENT PERFORMANCE!");
            System.out.println("YOU REALLY CRUSHED IT THIS WEEK!");
            System.out.println("Hats off to you!");
        }
        
        System.out.println("==================================================");
        System.out.println("               Thank you for playing!            ");
        System.out.println("==================================================");
    }
}
