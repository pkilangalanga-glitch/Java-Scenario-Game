
package eduvosonboardinggame;


public abstract class classScenario {
    public abstract void playclassScenario(Student student);
    
}
