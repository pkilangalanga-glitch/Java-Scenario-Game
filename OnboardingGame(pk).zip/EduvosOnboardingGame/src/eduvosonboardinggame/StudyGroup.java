
package eduvosonboardinggame;

import java.util.Scanner;

public class StudyGroup extends classScenario{
    @Override
    public void playclassScenario(Student student){
        Scanner input = new Scanner(System.in);
        
        while(true){
            try{
                System.out.println("==========Welcome to Day 4: Study Group day!==========");
                System.out.println("1.Join study group (+15 score, -10 energy)");
                System.out.println("2.Self study (+10 score, -5 energy)");
                System.out.println("Choose option 1 or 2: ");
                
                int choice = input.nextInt();
                
                switch (choice) {
                    case 1 -> {
                        student.updateScore(15);
                        student.updateEnergy(-10);
                        return;
                    }
                    case 2 -> {
                        student.updateScore(10);
                        student.updateEnergy(-5);
                        return;
                    }
                    default -> System.out.println("Invalid option! Try again.");
                }
                } catch (Exception e){
                    System.out.println("INSERT NUMBERS ONLY.");
            }
        }
    }
    
}
