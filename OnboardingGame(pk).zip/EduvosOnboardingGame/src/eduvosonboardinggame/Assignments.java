
package eduvosonboardinggame;

import java.util.Scanner;

public class Assignments extends classScenario {

    @Override
    public void playclassScenario(Student student) {
        Scanner input = new Scanner(System.in);
        int choice;
        
                System.out.println("==========Welcome to Day 3: Assignmet day!==========");
                System.out.println("1.Begin assignment (+20 score, -20 energy)");
                System.out.println("2.Postpone assignment(+5 score, -5 energy)");
            
            while(true){
                try{
                    System.out.println("Enter your choice (1 or 2): ");
                    choice = Integer.parseInt(input.nextLine());
                    
                    if (choice == 1){
                        student.updateScore(20);
                        student.updateEnergy(-20);
                        return;
                    } else if (choice == 2){ 
                        student.updateScore(5);
                        student.updateEnergy(-5);
                        return;
                    }
                    else {
                        System.out.println("CHOOSE EITHER 1 OR 2.");
                    }
                }catch (Exception e){
                            System.out.println ("INVALID INPUT! ENTER A NUMBER.");
                    }
                }
            }
        }
   
