
package eduvosonboardinggame;


public class Student {
    private String name;
    private int energy;
    private int academicScore;
    
  public Student(String name, int energy, int academicScore){
      this.name = name;
      this.energy = 70;
      this.academicScore = 0; 
  }
  public void updateEnergy(int value){
      this.energy += value;
  } 
  public void updateScore(int value){
      this.academicScore += value;
  }
  public String getName(){
      return name;
  }
  public int getEnergy(){
      return energy;
  }
  public int getAcademicScore(){
      return academicScore;
  }
}
