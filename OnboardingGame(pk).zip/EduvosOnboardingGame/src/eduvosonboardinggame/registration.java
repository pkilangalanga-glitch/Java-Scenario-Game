
package eduvosonboardinggame;

import java.util.Scanner;



public class registration extends classScenario{

    @Override
    public void playclassScenario(Student student) {
     Scanner scanner = new Scanner(System.in);
     int choice;
     
     System.out.println ("==========Welcome to Day 1: Registraton day!==========");
     System.out.println ("1.Arrive early (+10 score, -10 energy)");
     System.out.println("2. Arrive late (+5 score, -5 energy)");
     
     while(true){
         try{
             System.out.println("Enter your choice (1 or 2): ");
             choice = Integer.parseInt(scanner.nextLine());
             
          if (choice ==1){
              student.updateScore(10);
              student.updateEnergy(-10);
              return;
          } else if (choice ==2){
              student.updateScore(5);
              student.updateEnergy(-5);
              return;
          } else {
              System.out.println("Invalid selection! choose either 1 0r 2.");
          }
      
          } catch (Exception e){
          System.out.println("INVALID INPUT! PLEASE ENTER A NUMBER.");
          }
         
     }
    }

   
    
}
