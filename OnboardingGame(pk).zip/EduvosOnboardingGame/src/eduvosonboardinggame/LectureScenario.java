
package eduvosonboardinggame;

import java.util.Scanner;

public class LectureScenario extends classScenario {
    
    @Override
    public void playclassScenario(Student student){
        Scanner input = new Scanner(System.in);
        int choice;
        
       System.out.println("==========Welcome to day 2: Lecture 1! ========== ");
       System.out.println("1. Attend lecture (+15 score, -15 energy)");
       System.out.println("2. Arrive late (0 score, +5 energy)");
       System.out.println("3. Bunk lecture (0 score, +10 energy)");
       
       while (true){
           try{
               System.out.println("Enter your choice (1, 2, or 3):");
               choice = Integer.parseInt(input.nextLine());
               
               switch (choice) {
                   case 1:
                       student.updateScore(15);
                       student.updateEnergy(-15);
                       return;
                   case 2:
                       student.updateEnergy(5);
                       return;
                   case 3:
                       student.updateEnergy(10);
                       return;
                   default:
                       System.out.println ("IInvalid selection! choose 1, 2 or 3.");
                       break;
               }
           }catch (Exception e){
               System.out.println("INPUT NUMBERS ONLY! TRY AGAIN.");
             input.next(); 
           }
              
           }  
       }
    }  

   
