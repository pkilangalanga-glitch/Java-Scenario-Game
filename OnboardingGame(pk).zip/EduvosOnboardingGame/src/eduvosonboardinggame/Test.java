
package eduvosonboardinggame;

import java.util.Scanner;

public class Test extends classScenario{
    
    @Override
    public void playclassScenario(Student student){
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        System.out.println("==========Welcome to day 5: Test Day!==========");
        System.out.println("1. Write test prepared: (+25 score, -20 energy)");
        System.out.println("2. Write test unprepared: (+10 score, -10 energy)");
        
        
        while(true){
            try{
                System.out.println("Choose option 1 or 2: ");
                choice = Integer.parseInt(scanner.nextLine());
            
        
        
        switch (choice) {
                    case 1:
                        student.updateScore(25);
                        student.updateEnergy(-20);
                    return;

                    case 2:
                        student.updateScore(10);
                        student.updateEnergy(-10);
                    return;

                    default: System.out.println("Invalid option! Try again.");
                }
        
                } catch (Exception e) {
                    System.out.println("INSERT NUMBERS ONLY.");
                }
        }
}    }
    
    
